<?php

namespace KitLoong\MigrationsGenerator\Schema;

interface MySQLSchema extends Schema
{
}
