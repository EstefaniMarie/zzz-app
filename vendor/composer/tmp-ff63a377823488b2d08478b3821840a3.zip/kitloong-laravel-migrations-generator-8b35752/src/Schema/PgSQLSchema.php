<?php

namespace KitLoong\MigrationsGenerator\Schema;

interface PgSQLSchema extends Schema
{
}
