<?php

namespace KitLoong\MigrationsGenerator\Schema;

interface SQLSrvSchema extends Schema
{
}
