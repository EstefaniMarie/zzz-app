<?php

namespace KitLoong\MigrationsGenerator\Schema;

interface SQLiteSchema extends Schema
{
}
