<?php

namespace KitLoong\MigrationsGenerator\Schema\Models;

interface Model
{
}
