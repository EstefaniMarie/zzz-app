<?php

namespace KitLoong\MigrationsGenerator\Enum\Migrations\Method;

use BackedEnum;

interface MethodName extends BackedEnum
{
}
