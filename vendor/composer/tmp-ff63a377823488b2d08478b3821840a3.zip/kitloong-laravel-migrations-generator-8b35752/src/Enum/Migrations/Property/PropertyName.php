<?php

namespace KitLoong\MigrationsGenerator\Enum\Migrations\Property;

use BackedEnum;

interface PropertyName extends BackedEnum
{
}
