<?php

namespace KitLoong\MigrationsGenerator\Database\Models\SQLite;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseUDTColumn;

class SQLiteUDTColumn extends DatabaseUDTColumn
{
}
