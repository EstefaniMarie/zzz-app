<?php

namespace KitLoong\MigrationsGenerator\Database\Models\SQLite;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseForeignKey;

class SQLiteForeignKey extends DatabaseForeignKey
{
}
