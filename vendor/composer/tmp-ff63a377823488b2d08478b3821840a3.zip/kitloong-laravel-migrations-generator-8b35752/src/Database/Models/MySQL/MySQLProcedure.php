<?php

namespace KitLoong\MigrationsGenerator\Database\Models\MySQL;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseProcedure;

class MySQLProcedure extends DatabaseProcedure
{
}
