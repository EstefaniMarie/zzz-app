<?php

namespace KitLoong\MigrationsGenerator\Database\Models\MySQL;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseForeignKey;

class MySQLForeignKey extends DatabaseForeignKey
{
}
