<?php

namespace KitLoong\MigrationsGenerator\Database\Models\SQLSrv;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseProcedure;

class SQLSrvProcedure extends DatabaseProcedure
{
}
