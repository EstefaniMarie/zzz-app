<?php

namespace KitLoong\MigrationsGenerator\Database\Models\SQLSrv;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseForeignKey;

class SQLSrvForeignKey extends DatabaseForeignKey
{
}
