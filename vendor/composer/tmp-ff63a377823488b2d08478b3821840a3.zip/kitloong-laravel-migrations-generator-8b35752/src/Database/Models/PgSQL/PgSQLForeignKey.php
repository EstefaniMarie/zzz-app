<?php

namespace KitLoong\MigrationsGenerator\Database\Models\PgSQL;

use KitLoong\MigrationsGenerator\Database\Models\DatabaseForeignKey;

class PgSQLForeignKey extends DatabaseForeignKey
{
}
